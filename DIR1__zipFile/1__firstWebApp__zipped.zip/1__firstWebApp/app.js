/**
 * FocusFlow - Modern 35-Minute Pomodoro Timer
 */

(() => {
  // Configuration
  const DEFAULT_MINUTES = 35;
  const DEFAULT_SECONDS = DEFAULT_MINUTES * 60;
  const CIRCLE_RADIUS = 140;
  const CIRCUMFERENCE = 2 * Math.PI * CIRCLE_RADIUS; // ~879.6459

  // State
  let totalTime = DEFAULT_SECONDS;
  let timeRemaining = DEFAULT_SECONDS;
  let isRunning = false;
  let timerInterval = null;
  let endTime = null;
  let completedSessions = 0;

  // DOM Elements
  const timerDisplay = document.getElementById('timerDisplay');
  const timerSubtext = document.getElementById('timerSubtext');
  const progressCircle = document.getElementById('progressCircle');
  const startPauseBtn = document.getElementById('startPauseBtn');
  const startPauseText = document.getElementById('startPauseText');
  const playIcon = startPauseBtn.querySelector('.play-icon');
  const pauseIcon = startPauseBtn.querySelector('.pause-icon');
  const resetBtn = document.getElementById('resetBtn');
  const statusBadge = document.getElementById('statusBadge');
  const statusText = document.getElementById('statusText');
  const sessionCount = document.getElementById('sessionCount');
  const soundToggleBtn = document.getElementById('soundToggleBtn');
  const plusMinuteBtn = document.getElementById('plusMinuteBtn');
  const minusMinuteBtn = document.getElementById('minusMinuteBtn');
  const resetPresetBtn = document.getElementById('resetPresetBtn');

  // Initialize Progress Circle SVG stroke
  progressCircle.style.strokeDasharray = `${CIRCUMFERENCE} ${CIRCUMFERENCE}`;
  progressCircle.style.strokeDashoffset = '0';

  /**
   * Format seconds into MM:SS format
   */
  function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    const formattedMins = String(mins).padStart(2, '0');
    const formattedSecs = String(secs).padStart(2, '0');
    return `${formattedMins}:${formattedSecs}`;
  }

  /**
   * Update the UI display and circular progress ring
   */
  function updateDisplay() {
    const formatted = formatTime(timeRemaining);
    timerDisplay.textContent = formatted;

    // Document title
    if (isRunning) {
      document.title = `(${formatted}) 🍅 FocusFlow`;
    } else if (timeRemaining === 0) {
      document.title = `🎉 Time's up! - FocusFlow`;
    } else {
      document.title = `${formatted} - Pomodoro Timer`;
    }

    // Subtext message
    const minsLeft = Math.ceil(timeRemaining / 60);
    if (timeRemaining === 0) {
      timerSubtext.textContent = "Session complete! Great job.";
    } else if (timeRemaining < 60) {
      timerSubtext.textContent = `${timeRemaining} second${timeRemaining !== 1 ? 's' : ''} remaining`;
    } else {
      timerSubtext.textContent = `${minsLeft} minute${minsLeft !== 1 ? 's' : ''} remaining`;
    }

    // Circular Progress
    // When timeRemaining = totalTime -> progress = 1 -> strokeDashoffset = 0 (full)
    // When timeRemaining = 0 -> progress = 0 -> strokeDashoffset = CIRCUMFERENCE (empty)
    const progress = totalTime > 0 ? timeRemaining / totalTime : 0;
    const offset = CIRCUMFERENCE - (progress * CIRCUMFERENCE);
    progressCircle.style.strokeDashoffset = offset;
  }

  /**
   * Update Status Badge
   */
  function setStatus(state, message) {
    statusBadge.className = 'status-badge ' + state;
    statusText.textContent = message;
  }

  /**
   * Web Audio API Chime Synthesizer
   * Creates a rich, peaceful layered chime bell without any external audio files.
   */
  function playNotificationSound() {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;

      const ctx = new AudioCtx();

      // Frequencies for a soothing 4-tone ascending/harmonic zen chime (C5, E5, G5, C6)
      const notes = [
        { freq: 523.25, time: 0.0, duration: 1.8 },   // C5
        { freq: 659.25, time: 0.15, duration: 1.8 },  // E5
        { freq: 783.99, time: 0.30, duration: 2.0 },  // G5
        { freq: 1046.50, time: 0.45, duration: 2.5 }  // C6
      ];

      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(0.6, ctx.currentTime);
      masterGain.connect(ctx.destination);

      notes.forEach(note => {
        const osc = ctx.createOscillator();
        const noteGain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(note.freq, ctx.currentTime + note.time);

        // Gentle overtone
        const overtoneOsc = ctx.createOscillator();
        const overtoneGain = ctx.createGain();
        overtoneOsc.type = 'triangle';
        overtoneOsc.frequency.setValueAtTime(note.freq * 2, ctx.currentTime + note.time);

        // ADSR Envelope: fast attack, natural smooth exponential decay
        const startTime = ctx.currentTime + note.time;
        const endTime = startTime + note.duration;

        noteGain.gain.setValueAtTime(0, startTime);
        noteGain.gain.linearRampToValueAtTime(0.4, startTime + 0.04);
        noteGain.gain.exponentialRampToValueAtTime(0.0001, endTime);

        overtoneGain.gain.setValueAtTime(0, startTime);
        overtoneGain.gain.linearRampToValueAtTime(0.12, startTime + 0.03);
        overtoneGain.gain.exponentialRampToValueAtTime(0.0001, endTime);

        osc.connect(noteGain);
        overtoneOsc.connect(overtoneGain);

        noteGain.connect(masterGain);
        overtoneGain.connect(masterGain);

        osc.start(startTime);
        osc.stop(endTime);
        overtoneOsc.start(startTime);
        overtoneOsc.stop(endTime);
      });
    } catch (err) {
      console.warn('Audio playback error:', err);
    }
  }

  /**
   * Request Desktop Notification
   */
  function requestNotificationPermission() {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }

  function showDesktopNotification() {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification("FocusFlow - 35m Pomodoro Complete!", {
        body: "Great job! Your 35-minute focus session is finished. Time for a break!",
        icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🍅</text></svg>"
      });
    }
  }

  /**
   * Timer Tick Handler (Timestamp-based accurate delta tracking)
   */
  function tick() {
    const now = Date.now();
    const remainingMs = Math.max(0, endTime - now);
    timeRemaining = Math.ceil(remainingMs / 1000);

    updateDisplay();

    if (timeRemaining <= 0) {
      clearInterval(timerInterval);
      timerInterval = null;
      isRunning = false;

      // Handle session completion
      completedSessions++;
      sessionCount.textContent = completedSessions;

      setStatus('finished', "Time's Up! Great Work 🎉");
      startPauseText.textContent = "Start";
      playIcon.classList.remove('hidden');
      pauseIcon.classList.add('hidden');
      startPauseBtn.classList.remove('running');
      progressCircle.classList.remove('running');
      progressCircle.classList.add('completed');

      // Trigger alerts
      playNotificationSound();
      showDesktopNotification();
    }
  }

  /**
   * Start Timer
   */
  function startTimer() {
    if (timeRemaining <= 0) {
      timeRemaining = totalTime;
    }

    requestNotificationPermission();

    isRunning = true;
    endTime = Date.now() + timeRemaining * 1000;

    startPauseText.textContent = "Pause";
    playIcon.classList.add('hidden');
    pauseIcon.classList.remove('hidden');
    startPauseBtn.classList.add('running');
    progressCircle.classList.add('running');
    progressCircle.classList.remove('completed');

    setStatus('running', 'Focusing...');
    
    // Immediate tick & start interval
    tick();
    timerInterval = setInterval(tick, 200);
  }

  /**
   * Pause Timer
   */
  function pauseTimer() {
    if (!isRunning) return;

    isRunning = false;
    clearInterval(timerInterval);
    timerInterval = null;

    startPauseText.textContent = "Resume";
    playIcon.classList.remove('hidden');
    pauseIcon.classList.add('hidden');
    startPauseBtn.classList.remove('running');
    progressCircle.classList.remove('running');

    setStatus('paused', 'Timer Paused');
    updateDisplay();
  }

  /**
   * Reset Timer
   */
  function resetTimer(newSeconds = totalTime) {
    if (isRunning) {
      clearInterval(timerInterval);
      timerInterval = null;
      isRunning = false;
    }

    totalTime = newSeconds;
    timeRemaining = newSeconds;

    startPauseText.textContent = "Start";
    playIcon.classList.remove('hidden');
    pauseIcon.classList.add('hidden');
    startPauseBtn.classList.remove('running');
    progressCircle.classList.remove('running', 'completed');

    setStatus('', 'Ready to Focus');
    updateDisplay();
  }

  /**
   * Event Listeners
   */
  startPauseBtn.addEventListener('click', () => {
    if (isRunning) {
      pauseTimer();
    } else {
      startTimer();
    }
  });

  resetBtn.addEventListener('click', () => {
    resetTimer(totalTime);
  });

  // Sound test button
  soundToggleBtn.addEventListener('click', () => {
    playNotificationSound();
    requestNotificationPermission();
  });

  // Preset buttons
  resetPresetBtn.addEventListener('click', () => {
    resetPresetBtn.classList.add('active');
    resetTimer(DEFAULT_SECONDS);
  });

  plusMinuteBtn.addEventListener('click', () => {
    const newSeconds = Math.min(totalTime + 60, 180 * 60); // Max 3 hours
    resetTimer(newSeconds);
    if (newSeconds !== DEFAULT_SECONDS) {
      resetPresetBtn.classList.remove('active');
    }
  });

  minusMinuteBtn.addEventListener('click', () => {
    const newSeconds = Math.max(totalTime - 60, 60); // Min 1 minute
    resetTimer(newSeconds);
    if (newSeconds !== DEFAULT_SECONDS) {
      resetPresetBtn.classList.remove('active');
    }
  });

  // Keyboard shortcuts
  window.addEventListener('keydown', (e) => {
    // Avoid capturing if focused on input/textarea if any
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

    if (e.code === 'Space') {
      e.preventDefault();
      if (isRunning) {
        pauseTimer();
      } else {
        startTimer();
      }
    } else if (e.key === 'r' || e.key === 'R') {
      e.preventDefault();
      resetTimer(totalTime);
    }
  });

  // Initial display sync
  updateDisplay();
})();
